import jdk.jfr.internal.settings.EnabledSetting;

import java.util.Arrays;

public class Hotel {

    private static Room[] rooms2Choose = new Room[5];

    private int roomNumber;
    private int givenRoom;

    public int seeGivenRoom() {
        return this.givenRoom;
    }

    public Hotel(int roomNumber) {
        this.roomNumber=roomNumber;
        for (int i = 0; i < rooms2Choose.length; i++) {
            Room room = new Room(i);
            rooms2Choose[i] = room;
        }
    }

    public void checkIn() {

        for (int i = 0; i < rooms2Choose.length; i++) {
            if (rooms2Choose[i].showAvailability() == true) {
                System.out.println("You have Checked-In! Your room is room " + i);
                rooms2Choose[i].setAvailability(false);
                givenRoom = i;
                System.out.println("-------------------");
                break;
            }else if((rooms2Choose[rooms2Choose.length - 1].showAvailability()) == false){
                System.out.println("Oh no! All rooms are occupied!\n You'll have to look someplace else...");
                System.out.println("-------------------");
                break;
            } else if (rooms2Choose[i].showAvailability() == false) {
                System.out.println("Room " + i + " is occupied...\n Let's see more...");
                System.out.println("-------------------");
                if ((rooms2Choose[rooms2Choose.length - 1].showAvailability()) == false) {
                    System.out.println("Oh no! All rooms are occupied!\n You'll have to look someplace else...");
                    System.out.println("-------------------");
                    break;
                }
            }
        }
    }

    public void checkOut(int roomKey) {
        rooms2Choose[roomKey].setAvailability(true);
        System.out.println("You have Checked-Out!");
    }

}


