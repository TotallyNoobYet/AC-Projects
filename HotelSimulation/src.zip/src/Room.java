public class Room {

    private int roomNumber;

    private boolean isAvailable = true;


    public Room(int roomNumber){
        this.roomNumber = roomNumber;

    }


    public boolean showAvailability(){
        return this.isAvailable;
    }

    public void setAvailability(boolean isAvailable){
        this.isAvailable = isAvailable;
    }

}